/**
 * MapLeads · Content Script Engine
 * Google Maps DOM Extractor & Auto-Scroller
 */

(() => {
  if (window.__MAPLEADS_CONTENT_ACTIVE) return;
  window.__MAPLEADS_CONTENT_ACTIVE = true;
  
  function findFeedContainer() {
    return document.querySelector('div[role="feed"]') ||
    document.querySelector('div.m6QErb[aria-label]') ||
    document.querySelector('div.Nv2PK')?.closest('.m6QErb') ||
    document.querySelector('div.Nv2PK')?.parentElement;
  }
  
  function extractLeadsFromDOM() {
    const cards = document.querySelectorAll('div.Nv2PK, div[role="article"]');
    const leads = [];
    
    cards.forEach((card) => {
      const nameEl = card.querySelector('.qBF1Pd, .fontHeadlineSmall, [class*="fontHeadlineSmall"]');
      const name = nameEl ? nameEl.textContent.trim() : '';
      if (!name) return;
      
      const linkEl = card.querySelector('a.hfpxzc, a[href*="/maps/place/"]');
      const mapsUrl = linkEl ? linkEl.href : window.location.href;
      
      let rating = '';
      let reviews = '0';
      const ratingEl = card.querySelector('.MW4etd, span[aria-label*="star"], span[aria-label*="stars"]');
      if (ratingEl) {
        const ratingMatch = ratingEl.textContent.match(/\d+(\.\d+)?/);
        if (ratingMatch) rating = ratingMatch[0];
      }
      
      const reviewsEl = card.querySelector('.UY7F9, span[aria-label*="review"], span[aria-label*="reviews"]');
      if (reviewsEl) {
        const revClean = reviewsEl.textContent.replace(/[(),]/g, '').trim();
        const revMatch = revClean.match(/\d+/);
        if (revMatch) reviews = revMatch[0];
      }
      
      const textContainers = card.querySelectorAll('.W4Efsd');
      let category = 'Local Business';
      let phone = 'No phone';
      
      textContainers.forEach((tc) => {
        const txt = tc.textContent.trim();
        const phoneMatch = txt.match(/(?:\+?\d{1,4}[-.\s]?)?(?:\(?\d{2,5}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}/);
        if (phoneMatch && phoneMatch[0].replace(/\D/g, '').length >= 7) {
          if (!txt.includes('$') && !txt.includes('PKR') && !txt.includes('★')) {
            phone = phoneMatch[0].trim();
          }
        }
        
        if (!category || category === 'Local Business') {
          const parts = txt.split('·').map(p => p.trim());
          if (parts.length > 0 && parts[0] && !parts[0].includes('★') && !/\d{4,}/.test(parts[0])) {
            category = parts[0];
          }
        }
      });
      
      let websiteStatus = 'NO WEBSITE';
      let websiteUrl = '';
      
      const websiteEl = card.querySelector('a[data-value="Website"], a[aria-label*="website" i]');
      if (websiteEl && websiteEl.href) {
        websiteUrl = websiteEl.href;
        const lowUrl = websiteUrl.toLowerCase();
        
        if (lowUrl.includes('facebook.com') || lowUrl.includes('instagram.com') || lowUrl.includes('tiktok.com')) {
          websiteStatus = 'Social Profile Only';
        } else if (lowUrl.includes('google.com') || lowUrl.includes('business.site')) {
          websiteStatus = 'NO WEBSITE';
        } else {
          websiteStatus = 'Has Website';
        }
      }
      
      leads.push({
        name, category, rating, reviews, phone, websiteStatus, websiteUrl, mapsUrl
      });
    });
    
    return leads;
  }
  
  async function performAutoScroll(targetBatch = 30) {
    const feed = findFeedContainer();
    if (!feed) return extractLeadsFromDOM();
    
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const getCards = () => document.querySelectorAll('div.Nv2PK, div[role="article"]');
    
    const startCount = getCards().length;
    const targetCount = startCount + targetBatch;
    
    let previousCount = startCount;
    let idleCycles = 0;
    const maxCycles = 40;
    
    for (let i = 0; i < maxCycles; i++) {
      const text = feed.innerText || '';
      if (text.includes('end of the list') || text.includes('reached the end')) break;
      
      feed.scrollBy({ top: 400, behavior: 'smooth' });
      feed.dispatchEvent(new WheelEvent('wheel', { bubbles: true, deltaY: 600 }));
      
      const cards = getCards();
      if (cards.length > 0) cards[cards.length - 1].scrollIntoView({ behavior: 'smooth', block: 'end' });
      
      await sleep(300);
      
      const currentCount = getCards().length;
      if (currentCount >= targetCount) break;
      
      if (currentCount > previousCount) {
        previousCount = currentCount;
        idleCycles = 0;
      } else {
        idleCycles++;
        if (idleCycles >= 12) break;
      }
    }
    return extractLeadsFromDOM();
  }
  
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'SCAN_FEED') {
      sendResponse({ leads: extractLeadsFromDOM() });
      return true;
    }
    
    if (request.action === 'AUTO_SCROLL_AND_SCAN') {
      performAutoScroll(request.targetBatch || 30).then((leads) => {
        sendResponse({ leads });
      }).catch(err => {
        console.error('[MapLeads] Auto-scroll error:', err);
        sendResponse({ leads: extractLeadsFromDOM() });
      });
      return true;
    }
  });
})();