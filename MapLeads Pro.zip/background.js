/**
 * MapLeads - Background Service Worker (Manifest V3)
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[MapLeads] Extension installed successfully.');
  chrome.storage.local.get(['onlyOpportunities'], (result) => {
    if (result.onlyOpportunities === undefined) {
      chrome.storage.local.set({ onlyOpportunities: true });
    }
  });
});

function isGoogleMapsUrl(url) {
  if (!url) return false;
  return url.includes('google.com/maps') || url.includes('google.co') && url.includes('/maps');
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'CHECK_TAB_STATUS') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0) {
        const activeTab = tabs[0];
        const isValid = isGoogleMapsUrl(activeTab.url);
        sendResponse({ success: true, isValid, url: activeTab.url, tabId: activeTab.id });
      } else {
        sendResponse({ success: false, isValid: false });
      }
    });
    return true;
  } else if (request.type === 'PING') {
    sendResponse({ status: 'PONG', timestamp: Date.now() });
  }
});