/**
 * MapLeads · Client Hunter Open Source Engine
 */

const RTL_LANGUAGES = ['urdu', 'ar', 'fa'];

const LANG_LABELS = {
  roman_urdu: '🇵🇰 Roman Urdu', en: '🇬🇧 English', urdu: '🇵🇰 اردو', es: '🇪🇸 Español',
  ar: '🇸🇦 العربية', zh: '🇨🇳 中文', hi: '🇮🇳 हिन्दी', pt: '🇧🇷 Português', bn: '🇧🇩 বাংলা',
  ru: '🇷🇺 Русский', id: '🇮🇩 Indonesia', fr: '🇫🇷 Français', de: '🇩🇪 Deutsch',
  ja: '🇯🇵 日本語', tr: '🇹🇷 Türkçe', it: '🇮🇹 Italiano', vi: '🇻🇳 Tiếng Việt',
  ko: '🇰🇷 한국어', fa: '🇮🇷 فارسی', pl: '🇵🇱 Polski', nl: '🇳🇱 Nederlands',
  tl: '🇵🇭 Tagalog', th: '🇹🇭 ไทย', pa: '🇮🇳 ਪੰਜਾਬੀ'
};

const DEFAULT_TEMPLATES = {
  web: {
    roman_urdu: `Assalam-o-Alaikum {business} team! 👋\n\nGoogle Maps par aapka profile dekha, reviews aur rating ({rating}) kafi achi hain.\n\nLekin note kiya ke aapka koi official modern website ya catalog link nahi hai, jiski wajah se kafi prospective customers competitors ke paas chale jate hain.\n\nMain local {category} businesses ke liye mobile-friendly modern websites design karta hoon taake Maps se direct WhatsApp calls aur orders barh saken. Maine aapke setup ke liye ek quick concept design banaya hai—kya main WhatsApp pe chota sa demo share kar sakta hoon?`,
    en: `Hi team at {business}! 👋\n\nI was looking at top {category} providers in the area and noticed your strong {rating} Google profile.\n\nHowever, I noticed you don't have an official website linked for direct inquiries, meaning you might be losing customers to competitors who have one.\n\nI specialize in building clean, fast-loading modern websites for {category} businesses. I already drafted a quick concept for {business}—would you be open to taking a look?`,
    urdu: `السلام علیکم {business}! 👋\n\nگوگل میپس پر آپ کا بزنس پروفائل دیکھا، ریٹنگ ({rating}) کافی زبردست ہے۔\n\nلیکن نوٹ کیا کہ آپ کی کوئی باضابطہ ویب سائٹ موجود نہیں ہے، جس کی وجہ سے کئی گاہک دوسرے اداروں کی طرف چلے جاتے ہیں۔\n\nہم لوکل {category} بزنسز کے لیے جدید ویب سائٹس بناتے ہیں تاکہ میپس سے براہ راست کالز اور آرڈرز بڑھ سکیں۔ کیا میں آپ کو اس کا ایک مختصر ڈیمو بھیج سکتا ہوں؟`,
    es: `¡Hola equipo de {business}! 👋\n\nRevisé su perfil de {category} en Google Maps y tienen excelentes reseñas con una calificación de {rating}.\n\nSin embargo, noté que no tienen un sitio web oficial vinculado, lo que significa que podrían estar perdiendo clientes potenciales frente a competidores locales.\n\nDiseño sitios web modernos y optimizados para dispositivos móviles para negocios de {category}. ¿Tendrían 5 minutos esta semana para ver una demostración rápida para su negocio?`,
    ar: `مرحباً بفريق {business}! 👋\n\nلقد اطلعت على ملفكم التجاري في Google Maps في مجال {category} وتقييمكم ممتاز ({rating}).\n\nومع ذلك، لاحظت عدم وجود موقع إلكتروني رسمي مربوط بصفحتكم، مما قد يفقدكم عملاء لصالح المنافسين.\n\nنحن متخصصون في تصميم مواقع إلكترونية سريعة وحديثة لزيادة الحجوزات والاتصالات المباشرة. هل يمكنني مشاركة نموذج أولي سريع معكم عبر الواتساب؟`,
    zh: `您好，{business} 团队！👋\n\n我在谷歌地图上看到了您的 {category} 业务，评分非常出色（{rating}）。\n\n不过我注意到您尚未绑定官方网站，这可能会让您流失部分潜在客户。\n\n我们专注于为 {category} 商家打造响应式现代网站以提高在线咨询量。这周您有空看一个简短的概念演示吗？`,
    hi: `नमस्ते {business} टीम! 👋\n\nमैंने Google Maps पर आपका {category} प्रोफाइल देखा, आपकी {rating} स्टार रेटिंग बहुत अच्छी है।\n\nलेकिन आपके प्रोफाइल पर कोई आधिकारिक वेबसाइट लिंक नहीं है, जिससे ग्राहक प्रतिस्पर्धियों के पास जा सकते हैं।\n\nहम {category} व्यवसायों के लिए आधुनिक और तेज़ वेबसाइट डिज़ाइन करते हैं। क्या मैं आपको एक छोटा डेमो दिखा सकता हूँ?`,
    pt: `Olá equipe da {business}! 👋\n\nVi o perfil de vocês no Google Maps com uma ótima avaliação de {rating} para serviços de {category}.\n\nNo entanto, notei que não possuem um site oficial vinculado, o que pode fazer vocês perderem clientes para a concorrência.\n\nDesenvolvemos sites modernos e responsivos focados em converter visitas em agendamentos diretos. Posso enviar uma prévia rápida no WhatsApp?`,
    bn: `হ্যালো {business} টিম! 👋\n\nগুগল ম্যাপে আপনার {category} ব্যবসা দেখলাম, আপনার {rating} রেটিং চমৎকার।\n\nকিন্তু আপনার কোনো অফিসিয়াল ওয়েবসাইট যুক্ত নেই। আমরা লোকাল ব্যবসার জন্য আধুনিক ওয়েবসাইট তৈরি করি যা সরাসরি সেল বাড়ায়। আপনি কি একটি সংক্ষিপ্ত ডেমো দেখতে আগ্রহী?`,
    ru: `Здравствуйте, команда {business}! 👋\n\nУвидел вашу карточку на Google Maps в категории {category} с отличным рейтингом {rating}.\n\nОднако у вас не указан официальный сайт, из-за чего часть клиентов может уходить к конкурентам.\n\nМы разрабатываем быстрые конверсионные сайты для бизнеса. Могу ли я прислать вам краткий концепт в WhatsApp?`,
    id: `Halo tim {business}! 👋\n\nSaya melihat profil Google Maps Anda di kategori {category} dengan ulasan {rating} yang sangat bagus.\n\nNamun, belum ada website resmi yang terhubung. Kami membantu bisnis lokal membuat website modern untuk meningkatkan panggilan langsung. Boleh saya bagikan demo singkatnya?`,
    fr: `Bonjour l'équipe de {business} ! 👋\n\nJ'ai vu votre profil sur Google Maps pour {category} avec une excellente note de {rating}.\n\nCependant, vous n'avez pas de site web officiel lié, ce qui peut vous faire perdre des clients au profit de vos concurrents.\n\nNous concevons des sites web modernes et rapides pour {category}. Seriez-vous ouvert à une courte démonstration conceptuelle cette semaine ?`,
    de: `Hallo Team von {business}! 👋\n\nIch habe Ihr Google Maps-Profil für {category} mit der starken {rating}-Bewertung gesehen.\n\nAllerdings ist keine offizielle Website verlinkt, wodurch wertvolle Neukunden an Mitbewerber verloren gehen können.\n\nWir erstellen moderne, conversion-starke Websites für {category}-Betriebe. Hätten Sie Zeit für eine kurze Präsentation?`,
    ja: `{business}のご担当者様、こんにちは！👋\n\nGoogleマップで{category}のプロフィールを拝見し、{rating}の高評価が印象的でした。\n\n現在公式Webサイトが登録されていないため、見込み顧客を逃している可能性があります。集客に直結するモダンなWebサイトの無料サンプルをご覧になりませんか？`,
    tr: `Merhaba {business} ekibi! 👋\n\nGoogle Haritalar'da {category} profilinizi ve {rating} yıldızlı harika puanınızı gördüm.\n\nAncak resmi bir web siteniz bağlı değil, bu da potansiyel müşterilerin rakiplere gitmesine yol açabilir.\n\n{category} işletmeleri için hızlı ve modern web siteleri tasarlıyoruz. Size kısa bir örnek çalışma iletebilir miyim?`,
    it: `Ciao team di {business}! 👋\n\nHo visto il vostro profilo su Google Maps come {category} con un ottimo punteggio di {rating}.\n\nTuttavia, non avete un sito web ufficiale collegato, rischiando di perdere contatti a favore dei concorrenti.\n\nRealizziamo siti web moderni e veloci per attività locali. Posso inviarvi una rapida anteprima su WhatsApp?`,
    vi: `Xin chào {business}! 👋\n\nTôi thấy hồ sơ của bạn trên Google Maps trong lĩnh vực {category} với đánh giá rất tốt {rating}.\n\nTuy nhiên, bạn chưa có website chính thức liên kết. Chúng tôi chuyên thiết kế website hiện đại giúp tăng khách hàng gọi trực tiếp. Tôi có thể gửi bạn bản demo ngắn xem thử không?`,
    ko: `안녕하세요, {business} 대표님! 👋\n\n구글 지도에서 {category} 매장과 {rating}점의 우수한 리뷰를 확인했습니다.\n\n다만 공식 웹사이트가 등록되어 있지 않아 잠재 고객이 경쟁업체로 이탈할 수 있습니다. 모바일 친화적인 맞춤형 웹사이트 샘플을 짧게 확인해보시겠습니까?`,
    fa: `درود بر تیم {business}! 👋\n\nپروفایل شما در گوگل مپ در حوزه {category} با امتیاز عالی {rating} را بررسی کردم.\n\nاما متوجه شدم وب‌سایت رسمی ثبت نکرده‌اید و ممکن است مشتریان جذب رقبا شوند. ما وب‌سایت‌های مدرن برای افزایش تماس مستقیم طراحی می‌کنیم. مایلید یک پیش‌نمایش سریع برایتان ارسال کنم؟`,
    pl: `Dzień dobry zespołowi {business}! 👋\n\nZauważyłem Wasz profil w Google Maps w kategorii {category} z بسیار dobą oceną {rating}.\n\nNie macie jednak podlinkowanej oficjalnej strony www, przez co klienci mogą wybierać konkurencję.\n\nTworzymy nowoczesne strony zwiększające liczbę zapytań. Czy mogę przesłać krótką bezpłatną koncepcję?`,
    nl: `Hallo team van {business}! 👋\n\nIk zag jullie Google Maps-profiel voor {category} met een geweldige beoordeling van {rating}.\n\nEr is echter geen officiële website gekoppeld, waardoor potentiële klanten naar concurrenten kunnen gaan.\n\nWij bouwen snelle, moderne websites voor lokale bedrijven. Kan ik u een korte preview sturen via WhatsApp?`,
    tl: `Kumusta {business} team! 👋\n\nNakita ko ang profile ninyo sa Google Maps bilang {category} na may magandang {rating} rating.\n\nNapansin ko lang po na wala kayong official website link, kaya posibleng napupunta ang ibang customers sa competitors. Gumagawa kami ng modernong website para mas dumami ang direct bookings ninyo. Pwede po ba mag-share ng quick demo?`,
    th: `สวัสดีทีมงาน {business}! 👋\n\nผมเห็นข้อมูลธุรกิจ {category} ของคุณบน Google Maps พร้อมคะแนนรีวิว {rating} ที่ยอดเยี่ยม\n\nแต่ยังไม่มีลิงก์เว็บไซต์อย่างเป็นทางการ ซึ่งอาจทำให้เสียโอกาสให้คู่แข่งได้ เราช่วยสร้างเว็บไซต์ทันสมัยเพื่อเพิ่มยอดจอง สนใจดูตัวอย่างสั้นๆ ทาง WhatsApp ไหมครับ?`,
    pa: `ਸਤਿ ਸ਼੍ਰੀ ਅਕਾਲ {business} ਟੀਮ! 👋\n\nਗੂਗਲ ਮੈਪਸ 'ਤੇ ਤੁਹਾਡਾ {category} ਪ੍ਰੋਫਾਈਲ ਦੇਖਿਆ, ਰੇਟਿੰਗ ({rating}) ਬਹੁਤ ਵਧੀਆ ਹੈ।\n\nਪਰ ਤੁਹਾਡੀ ਕੋਈ ਅਧਿਕਾਰਤ ਵੈੱਬਸਾਈਟ ਨਹੀਂ ਹੈ। ਅਸੀਂ ਲੋਕਲ ਬਿਜ਼ਨਸ ਲਈ ਮਾਡਰਨ ਵੈੱਬਸਾਈਟਾਂ ਬਣਾਉਂਦੇ ਹਾਂ ਤਾਂ ਜੋ ਗਾਹਕ ਸਿੱਧੇ ਸੰਪਰਕ ਕਰ ਸਕਣ। ਕੀ ਮੈਂ ਤੁਹਾਨੂੰ ਇਕ ਛੋਟਾ ਡੈਮੋ ਭੇਜ ਸਕਦਾ ਹਾਂ?`
  },
  smm: {
    roman_urdu: `Assalam-o-Alaikum {business} team! 👋\n\nAapka Google Maps par business dekha, reputation kafi solid hai ({rating} rating).\n\nLekin notice kiya ke social media (Instagram aur Facebook) par consistent reels ya content active nahi hai jahan se aj kal 70% naye local customers aate hain.\n\nMain {category} businesses ke liye short videos, viral reels aur complete social media marketing handle karta hoon. Kya main aapke business ke mutabiq 3 high-converting post ideas share karoon?`,
    en: `Hi {business}! 👋\n\nFound your business on Google Maps with great {rating} reviews. I noticed your social channels (Instagram/Facebook) aren't active with short-form reels where most local customers now look.\n\nI run high-converting social media marketing and content creation for {category} businesses. Would you be open to 3 quick content ideas tailored to your brand?`,
    urdu: `السلام علیکم {business}! 👋\n\nگوگل میپس پر آپ کا کاروبار دیکھا، ریٹنگ ({rating}) بہترین ہے۔\n\nلیکن سوشل میڈیا (انسٹاگرام اور فیس بک) پر کوئی فعال تشہیر یا ویڈیوز موجود نہیں ہیں جہاں سے روزانہ درجنوں نئے کسٹمرز آتے ہیں۔\n\nہم {category} کے لیے سوشل میڈیا مارکیٹنگ اور ویڈیوز سنبھالتے ہیں۔ کیا میں آپ کو اس کے چند نمونے بھیج سکتا ہوں؟`
  },
  seo: {
    roman_urdu: `Assalam-o-Alaikum {business}! 👋\n\nGoogle Maps par search karne par aapka profile mila. Rating ({rating}) toh achi hai lekin profile top 3 map rankings me nahi aa raha, jiski wajah se rozana Maps ke 50+ genuine customers aapke competitors ke paas ja rahe hain.\n\nMain Google Business Profile (GMB) SEO optimize karta hoon taake aapka setup keyword search par top 1-3 me rank kare. Kya main aapko ek free 2-minute audit report bhej sakta hoon?`,
    en: `Hi {business}! 👋\n\nI noticed your business on Google Maps with {rating} stars. However, your profile isn't ranking in the top 3 local map pack for common searches, which means potential customers are calling your competitors instead.\n\nI specialize in Local SEO and Google Business Profile ranking for {category} businesses. Would you be open to a quick, free local visibility audit?`,
    urdu: `السلام علیکم {business}! 👋\n\nگوگل میپس پر آپ کا پروفائل دیکھا، ریٹنگ ({rating}) اچھی ہے۔ لیکن آپ کا پروفائل سرچ کے پہلے 3 نتائج میں شامل نہیں ہے، جس کی وجہ سے روزانہ کئی گاہک دوسروں کے پاس چلے جاتے ہیں۔\n\nہم لوکل گوگل رینکنگ (SEO) بہتر بناتے ہیں تاکہ آپ کا کاروبار ٹاپ پر آئے۔ کیا میں آپ کو اس کی مفت رپورٹ بھیج سکتا ہوں؟`
  },
  branding: {
    roman_urdu: `Assalam-o-Alaikum {business}! 👋\n\nGoogle profile dekha aapka. Hum local {category} businesses ke liye premium visual branding, high-converting digital promo banners, rate cards aur logos design karte hain jo business ko high-end look dete hain.\n\nMaine aapke brand ke liye 2 quick mockups soche hain—kya main WhatsApp par share kar sakta hoon?`,
    en: `Hi {business}! 👋\n\nLoved your Google presence and {rating} rating. I design premium visual branding, digital menus, promo banners, and high-converting marketing creatives for {category} businesses.\n\nI’d love to send over 2 quick sample mockups tailored for {business}—open to checking them out?`,
    urdu: `السلام علیکم {business}! 👋\n\nگوگل میپس پر آپ کا پروفائل دیکھا۔ ہم لوکل {category} کے لیے جدید ڈیجیٹل بینرز، مینیو اور شاندار برانڈنگ ڈیزائن تیار کرتے ہیں۔ کیا میں آپ کو اپنے کام کے کچھ ڈیزائن بھیج سکتا ہوں؟`
  }
};

let state = {
  activeTab: null, isValidMapsPage: false, allLeads: [], searchQuery: '', 
  onlyOpportunities: false, minScore: 0, crmFilter: 'ALL', 
  selectedLeadForPitch: null, activePitchLang: 'roman_urdu', activeService: 'web', customTemplates: {}
};

let currentModalCallback = null;

function calculateLeadScore(lead) {
  let score = 0;
  if (lead.websiteStatus === 'NO WEBSITE') score += 40;
  else if (lead.websiteStatus === 'Social Profile Only') score += 25;
  
  const hasPhone = lead.phone && lead.phone !== 'No phone' && lead.phone.replace(/\D/g, '').length >= 7;
  if (hasPhone) score += 25;
  
  const reviewCount = parseInt(lead.reviews || 0, 10);
  if (!isNaN(reviewCount)) {
    if (reviewCount < 15) score += 20;
    else if (reviewCount < 45) score += 12;
    else if (reviewCount < 100) score += 6;
  }
  
  const rating = parseFloat(lead.rating || 0);
  if (!isNaN(rating) && rating > 0) {
    if (rating <= 4.3) score += 15;
    else if (rating <= 4.7) score += 10;
    else score += 5;
  }
  return Math.min(100, Math.max(10, score));
}

function mergeAndDeduplicate(existingLeads, newLeads) {
  const map = new Map();
  for (const lead of existingLeads) {
    const key = (lead.phone && lead.phone !== 'No phone') ? lead.phone : lead.name.trim().toLowerCase();
    map.set(key, lead);
  }
  for (const lead of newLeads) {
    const key = (lead.phone && lead.phone !== 'No phone') ? lead.phone : lead.name.trim().toLowerCase();
    if (map.has(key)) {
      const existing = map.get(key);
      map.set(key, {
        ...lead, crmStatus: existing.crmStatus || 'New',
        socials: { ...existing.socials, ...lead.socials }, _socialsEnriched: existing._socialsEnriched || false
      });
    } else {
      map.set(key, {
        ...lead, crmStatus: lead.crmStatus || 'New',
        socials: lead.socials || { instagram: null, facebook: null, linkedin: null, tiktok: null }, _socialsEnriched: false
      });
    }
  }
  const merged = Array.from(map.values());
  merged.forEach(l => triggerSocialEnrichment(l));
  return merged;
}

function triggerSocialEnrichment(lead) {
  if (!lead.websiteUrl || lead.websiteStatus !== 'Has Website' || lead._socialsEnriched) return;
  lead._socialsEnriched = true;
  chrome.runtime.sendMessage({ action: 'ENRICH_SOCIALS', website: lead.websiteUrl }, (response) => {
    if (response && response.success && response.socials) {
      let changed = false;
      ['instagram', 'facebook', 'linkedin', 'tiktok'].forEach(platform => {
        if (!lead.socials[platform] && response.socials[platform]) {
          lead.socials[platform] = response.socials[platform];
          changed = true;
        }
      });
      if (changed) {
        chrome.storage.local.set({ savedLeads: state.allLeads });
        renderUI();
      }
    }
  });
}

function getTemplateText(service, lang) {
  if (state.customTemplates[service] && state.customTemplates[service][lang]) return state.customTemplates[service][lang];
  if (DEFAULT_TEMPLATES[service] && DEFAULT_TEMPLATES[service][lang]) return DEFAULT_TEMPLATES[service][lang];
  if (DEFAULT_TEMPLATES.web[lang]) return DEFAULT_TEMPLATES.web[lang];
  return DEFAULT_TEMPLATES[service]?.en || DEFAULT_TEMPLATES.web.en;
}

function generateOutreachPitch(lead, service = 'web', lang = 'roman_urdu') {
  const rawTemplate = getTemplateText(service, lang);
  const bizName = lead.name || 'Business Owner';
  const category = cleanCategory(lead.category);
  const ratingText = lead.rating ? `${lead.rating}★` : '4.5★';
  return rawTemplate.replace(/{business}/g, bizName).replace(/{category}/g, category).replace(/{rating}/g, ratingText);
}

function getCleanWhatsAppUrl(phone, customText = '') {
  if (!phone || phone === 'No phone') return null;
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 9) return null;
  const encodedMsg = encodeURIComponent(customText);
  return `https://wa.me/${digits}${customText ? `?text=${encodedMsg}` : ''}`;
}

function showToast(msg, duration = 1800) {
  const toast = document.getElementById('toastNotice');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('visible');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.remove('visible'), duration);
}

function showModal({ title, desc, actionText, callback }) {
  const modal = document.getElementById('customModal');
  const titleEl = document.getElementById('modalTitle');
  const descEl = document.getElementById('modalDesc');
  const btnAction = document.getElementById('btnModalAction');
  
  if (titleEl) titleEl.textContent = title;
  if (descEl) descEl.textContent = desc;
  if (btnAction) {
    btnAction.textContent = actionText || 'Continue';
    currentModalCallback = callback || null;
  }
  if (modal) modal.classList.remove('hidden');
}

function hideModal() {
  const modal = document.getElementById('customModal');
  if (modal) modal.classList.add('hidden');
  currentModalCallback = null;
}

function cleanCategory(rawCategory) {
  if (!rawCategory || typeof rawCategory !== 'string') return 'Local Business';
  let cleaned = rawCategory.trim().replace(/^[\d.,]+(?:\s*\(\d+\))?\s*(?:·|•|-)?\s*/i, '').trim();
  return (!cleaned || /^[\d.,\s()]+$/.test(cleaned)) ? 'Local Business' : cleaned;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function generateCSV(leads) {
  const headers = ['Score','Status','Name','Category','Rating','Reviews','Phone','Website Status','Website URL','Instagram','Facebook','LinkedIn','TikTok','Maps URL','WhatsApp URL'];
  const escapeCSV = (str) => `"${String(str ?? '').replace(/"/g, '""')}"`;
  const rows = leads.map(lead => [
    escapeCSV(calculateLeadScore(lead)), escapeCSV(lead.crmStatus || 'New'), escapeCSV(lead.name || ''), escapeCSV(cleanCategory(lead.category)),
    escapeCSV(lead.rating || ''), escapeCSV(lead.reviews || ''), escapeCSV(lead.phone || ''), escapeCSV(lead.websiteStatus || ''),
    escapeCSV(lead.websiteUrl || ''), escapeCSV(lead.socials?.instagram || ''), escapeCSV(lead.socials?.facebook || ''),
    escapeCSV(lead.socials?.linkedin || ''), escapeCSV(lead.socials?.tiktok || ''), escapeCSV(lead.mapsUrl || ''),
    escapeCSV(getCleanWhatsAppUrl(lead.phone, generateOutreachPitch(lead, state.activeService, state.activePitchLang)) || '')
  ]);
  return [headers.map(h => `"${h}"`).join(','), ...rows.map(r => r.join(','))].join('\n');
}

function downloadCSV(csvContent, filename) {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const CRM_CYCLE = ['New', 'Contacted', 'Replied', 'Client'];

function getFilteredLeads() {
  return state.allLeads.filter(lead => {
    if (state.onlyOpportunities && !(lead.websiteStatus === 'NO WEBSITE' || lead.websiteStatus === 'Social Profile Only')) return false;
    if (calculateLeadScore(lead) < state.minScore) return false;
    if (state.crmFilter !== 'ALL' && (lead.crmStatus || 'New') !== state.crmFilter) return false;
    if (state.searchQuery) {
      const q = state.searchQuery.toLowerCase();
      const nameMatch = (lead.name || '').toLowerCase().includes(q);
      const catMatch = cleanCategory(lead.category).toLowerCase().includes(q);
      if (!nameMatch && !catMatch) return false;
    }
    return true;
  });
}

function renderUI() {
  const totalScannedEl = document.getElementById('totalScanned');
  const totalOppsEl = document.getElementById('totalOpportunities');
  const highScoreCountEl = document.getElementById('highScoreCount');
  const previewCountEl = document.getElementById('previewCount');
  const feedContainer = document.getElementById('prospectFeed');
  const btnExport = document.getElementById('btnExport');
  
  const totalScanned = state.allLeads.length;
  const opportunities = state.allLeads.filter(l => l.websiteStatus === 'NO WEBSITE' || l.websiteStatus === 'Social Profile Only').length;
  const highScores = state.allLeads.filter(l => calculateLeadScore(l) >= 70).length;
  
  if (totalScannedEl) totalScannedEl.textContent = totalScanned;
  if (totalOppsEl) totalOppsEl.textContent = opportunities;
  if (highScoreCountEl) highScoreCountEl.textContent = highScores;
  
  const displayLeads = getFilteredLeads();
  if (previewCountEl) previewCountEl.textContent = `${displayLeads.length} ${displayLeads.length === 1 ? 'lead' : 'leads'}`;
  
  if (btnExport) {
    btnExport.disabled = displayLeads.length === 0;
    btnExport.textContent = displayLeads.length > 0 ? `📥 CSV (${displayLeads.length})` : '📥 CSV';
  }
  
  if (!feedContainer) return;
  
  if (displayLeads.length === 0) {
    feedContainer.innerHTML = `<div class="empty-state"><p>No prospects match active filters.</p><p style="font-size: 10px; margin-top: 3px; color: var(--text-dim);">Adjust filters above or clear search query.</p></div>`;
    return;
  }
  
  feedContainer.innerHTML = displayLeads.map((lead, index) => {
    const score = calculateLeadScore(lead);
    let scoreClass = 'score-low';
    if (score >= 70) scoreClass = 'score-high';
    else if (score >= 45) scoreClass = 'score-med';
    
    const crmStatus = lead.crmStatus || 'New';
    const waUrl = getCleanWhatsAppUrl(lead.phone, generateOutreachPitch(lead, state.activeService, state.activePitchLang));
    const hasSocials = lead.socials && (lead.socials.instagram || lead.socials.facebook || lead.socials.linkedin || lead.socials.tiktok);
    
    const socialPillsHtml = hasSocials ? `
    <div class="card-social-row">
    ${lead.socials.instagram ? `<a href="${lead.socials.instagram}" target="_blank" class="soc-pill ig" title="Instagram">IG</a>` : ''}
    ${lead.socials.facebook ? `<a href="${lead.socials.facebook}" target="_blank" class="soc-pill fb" title="Facebook">FB</a>` : ''}
    ${lead.socials.linkedin ? `<a href="${lead.socials.linkedin}" target="_blank" class="soc-pill li" title="LinkedIn">IN</a>` : ''}
    ${lead.socials.tiktok ? `<a href="${lead.socials.tiktok}" target="_blank" class="soc-pill tt" title="TikTok">TT</a>` : ''}
    </div>` : '';
    
    return `
    <div class="lead-card" style="--i: ${Math.min(index, 10)};">
    <div class="card-top">
    <span class="lead-name">${escapeHtml(lead.name)}</span>
    <span class="score-badge ${scoreClass}" title="Opportunity Score">${score}/100</span>
    </div>
    <div class="card-meta">
    <span>${escapeHtml(cleanCategory(lead.category))}</span>
    <span>★ ${escapeHtml(lead.rating || '-')} (${escapeHtml(lead.reviews || 0)})</span>
    </div>
    <div class="card-meta" style="font-size: 9.5px;">
    <span>📞 ${escapeHtml(lead.phone || 'No phone')}</span>
    <span style="color: ${lead.websiteStatus === 'NO WEBSITE' ? 'var(--rose)' : (lead.websiteStatus === 'Social Profile Only' ? 'var(--amber)' : 'var(--emerald)')}; font-weight: 700;">
    ${escapeHtml(lead.websiteStatus)}
    </span>
    </div>
    ${socialPillsHtml}
    <div class="card-bottom">
    <button class="crm-pill crm-${crmStatus}" data-key="${escapeHtml(lead.phone || lead.name)}" title="Click to cycle status">
    ● ${crmStatus === 'Client' ? 'Client Won' : crmStatus}
    </button>
    <div class="card-actions">
    <button class="btn-action-sm btn-pitch" data-pitch-idx="${index}">⚡ Pitch</button>
    ${waUrl ? `<a href="${waUrl}" target="_blank" class="btn-action-sm btn-wa" title="Open WhatsApp">💬 WA</a>` : ''}
    </div>
    </div>
    </div>`;
  }).join('');
  
  feedContainer.querySelectorAll('.crm-pill').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const targetKey = e.currentTarget.getAttribute('data-key');
      const lead = state.allLeads.find(l => (l.phone || l.name) === targetKey);
      if (lead) {
        const currentIdx = CRM_CYCLE.indexOf(lead.crmStatus || 'New');
        lead.crmStatus = CRM_CYCLE[(currentIdx + 1) % CRM_CYCLE.length];
        chrome.storage.local.set({ savedLeads: state.allLeads });
        showToast(`Status: ${lead.crmStatus}`);
        renderUI();
      }
    });
  });
  
  feedContainer.querySelectorAll('[data-pitch-idx]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.getAttribute('data-pitch-idx'), 10);
      const lead = displayLeads[idx];
      if (lead) openPitchModal(lead);
    });
  });
}

function updatePitchModalView() {
  if (!state.selectedLeadForPitch) return;
  const lead = state.selectedLeadForPitch;
  const box = document.getElementById('pitchText');
  const waBtn = document.getElementById('btnOpenWaPitch');
  const pitch = generateOutreachPitch(lead, state.activeService, state.activePitchLang);
  
  if (box) {
    box.value = pitch;
    if (RTL_LANGUAGES.includes(state.activePitchLang)) box.classList.add('rtl-text');
    else box.classList.remove('rtl-text');
  }
  
  const waUrl = getCleanWhatsAppUrl(lead.phone, pitch);
  if (waBtn) {
    if (waUrl) { waBtn.href = waUrl; waBtn.style.display = 'inline-flex'; }
    else waBtn.style.display = 'none';
  }
}

function openPitchModal(lead) {
  state.selectedLeadForPitch = lead;
  const modal = document.getElementById('pitchModal');
  const title = document.getElementById('pitchModalBizName');
  const selectedLangDisplay = document.getElementById('selectedLangDisplay');
  const langDropdownMenu = document.getElementById('langDropdownMenu');
  const langDropdownBtn = document.getElementById('langDropdownBtn');
  
  if (title) title.textContent = `Pitch: ${lead.name}`;
  if (langDropdownMenu) langDropdownMenu.classList.add('hidden');
  if (langDropdownBtn) langDropdownBtn.classList.remove('open');
  if (selectedLangDisplay) selectedLangDisplay.textContent = LANG_LABELS[state.activePitchLang] || '🇵🇰 Roman Urdu';
  
  document.querySelectorAll('.service-tab').forEach(tab => {
    if (tab.getAttribute('data-service') === state.activeService) tab.classList.add('active');
    else tab.classList.remove('active');
  });
  
  document.querySelectorAll('.lang-option').forEach(opt => {
    if (opt.getAttribute('data-lang') === state.activePitchLang) { opt.classList.add('active'); opt.scrollIntoView({ block: 'nearest' }); }
    else opt.classList.remove('active');
  });
  
  updatePitchModalView();
  if (modal) modal.classList.remove('hidden');
}

function updateStatusPill(isValid, isScanning = false, customText = '') {
  const statusPill = document.getElementById('statusPill');
  const btnScan = document.getElementById('btnScan');
  const btnAutoScroll = document.getElementById('btnAutoScroll');
  state.isValidMapsPage = isValid;
  
  if (statusPill) {
    if (customText) { statusPill.textContent = customText; statusPill.className = 'pill pill-ready'; }
    else if (isScanning) { statusPill.textContent = 'Scanning...'; statusPill.className = 'pill pill-ready'; }
    else if (isValid) { statusPill.textContent = 'Maps Ready'; statusPill.className = 'pill pill-ready'; }
    else { statusPill.textContent = 'Not on Maps'; statusPill.className = 'pill pill-not-ready'; }
  }
  if (btnScan) btnScan.disabled = !isValid || isScanning;
  if (btnAutoScroll) btnAutoScroll.disabled = !isValid || isScanning;
}

function initPopup() {
  if (typeof chrome === 'undefined' || !chrome.tabs) { updateStatusPill(false); return; }
  
  chrome.storage.local.get(['savedLeads','onlyOpportunities','minScore','crmFilter','activePitchLang','activeService','customTemplates'], (res) => {
    if (res.savedLeads && Array.isArray(res.savedLeads)) {
      state.allLeads = res.savedLeads;
      state.allLeads.forEach(l => triggerSocialEnrichment(l));
    }
    state.onlyOpportunities = res.onlyOpportunities || false;
    state.minScore = parseInt(res.minScore || 0, 10);
    state.crmFilter = res.crmFilter || 'ALL';
    state.activePitchLang = res.activePitchLang || 'roman_urdu';
    state.activeService = res.activeService || 'web';
    state.customTemplates = res.customTemplates || {};
    
    if (document.getElementById('onlyOpportunitiesToggle')) document.getElementById('onlyOpportunitiesToggle').checked = state.onlyOpportunities;
    if (document.getElementById('minScoreFilter')) document.getElementById('minScoreFilter').value = String(state.minScore);
    if (document.getElementById('crmFilter')) document.getElementById('crmFilter').value = state.crmFilter;
    
    renderUI();
  });
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs && tabs.length > 0) {
      state.activeTab = tabs[0];
      updateStatusPill((tabs[0].url || '').includes('google.com/maps'));
    } else updateStatusPill(false);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initPopup();
  
  const searchInput = document.getElementById('leadSearchInput');
  const btnSearchClear = document.getElementById('btnSearchClear');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value.trim();
      if (btnSearchClear) btnSearchClear.classList.toggle('visible', !!state.searchQuery);
      renderUI();
    });
  }
  if (btnSearchClear && searchInput) {
    btnSearchClear.addEventListener('click', () => {
      searchInput.value = ''; state.searchQuery = ''; btnSearchClear.classList.remove('visible'); renderUI();
    });
  }
  
  if (document.getElementById('minScoreFilter')) document.getElementById('minScoreFilter').addEventListener('change', (e) => { state.minScore = parseInt(e.target.value, 10); chrome.storage.local.set({ minScore: state.minScore }); renderUI(); });
  if (document.getElementById('onlyOpportunitiesToggle')) document.getElementById('onlyOpportunitiesToggle').addEventListener('change', (e) => { state.onlyOpportunities = e.target.checked; chrome.storage.local.set({ onlyOpportunities: state.onlyOpportunities }); renderUI(); });
  if (document.getElementById('crmFilter')) document.getElementById('crmFilter').addEventListener('change', (e) => { state.crmFilter = e.target.value; chrome.storage.local.set({ crmFilter: state.crmFilter }); renderUI(); });
  
  document.querySelectorAll('.service-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      state.activeService = e.currentTarget.getAttribute('data-service');
      chrome.storage.local.set({ activeService: state.activeService });
      document.querySelectorAll('.service-tab').forEach(t => t.classList.remove('active'));
      e.currentTarget.classList.add('active');
      updatePitchModalView();
    });
  });
  
  const langDropdownBtn = document.getElementById('langDropdownBtn');
  const langDropdownMenu = document.getElementById('langDropdownMenu');
  if (langDropdownBtn && langDropdownMenu) {
    langDropdownBtn.addEventListener('click', (e) => { e.stopPropagation(); langDropdownMenu.classList.toggle('hidden'); langDropdownBtn.classList.toggle('open'); });
    document.querySelectorAll('.lang-option').forEach(option => {
      option.addEventListener('click', (e) => {
        state.activePitchLang = e.currentTarget.getAttribute('data-lang');
        chrome.storage.local.set({ activePitchLang: state.activePitchLang });
        if (document.getElementById('selectedLangDisplay')) document.getElementById('selectedLangDisplay').textContent = LANG_LABELS[state.activePitchLang];
        document.querySelectorAll('.lang-option').forEach(opt => opt.classList.remove('active'));
        e.currentTarget.classList.add('active');
        langDropdownMenu.classList.add('hidden'); langDropdownBtn.classList.remove('open');
        updatePitchModalView();
      });
    });
    document.addEventListener('click', (e) => { if (!langDropdownMenu.contains(e.target) && !langDropdownBtn.contains(e.target)) { langDropdownMenu.classList.add('hidden'); langDropdownBtn.classList.remove('open'); } });
  }
  
  const btnSaveTemplate = document.getElementById('btnSaveTemplate');
  if (btnSaveTemplate) {
    btnSaveTemplate.addEventListener('click', () => {
      const box = document.getElementById('pitchText');
      if (!box) return;
      if (!state.customTemplates[state.activeService]) state.customTemplates[state.activeService] = {};
      state.customTemplates[state.activeService][state.activePitchLang] = box.value;
      chrome.storage.local.set({ customTemplates: state.customTemplates }, () => showToast('✓ Template Saved!'));
    });
  }
  
  const btnResetTemplate = document.getElementById('btnResetTemplate');
  if (btnResetTemplate) {
    btnResetTemplate.addEventListener('click', () => {
      if (state.customTemplates[state.activeService] && state.customTemplates[state.activeService][state.activePitchLang]) {
        delete state.customTemplates[state.activeService][state.activePitchLang];
        chrome.storage.local.set({ customTemplates: state.customTemplates }, () => { updatePitchModalView(); showToast('✓ Reset to Default'); });
      } else { updatePitchModalView(); showToast('✓ Already default'); }
    });
  }
  
  const pitchTextEl = document.getElementById('pitchText');
  if (pitchTextEl) {
    pitchTextEl.addEventListener('input', (e) => {
      if (!state.selectedLeadForPitch) return;
      const waUrl = getCleanWhatsAppUrl(state.selectedLeadForPitch.phone, e.target.value);
      if (document.getElementById('btnOpenWaPitch') && waUrl) document.getElementById('btnOpenWaPitch').href = waUrl;
    });
  }
  
  const btnClear = document.getElementById('btnClearFeed');
  if (btnClear) {
    btnClear.addEventListener('click', () => { state.allLeads = []; chrome.storage.local.remove(['savedLeads']); showToast('✓ Leads cleared'); renderUI(); });
  }
  
  const btnScan = document.getElementById('btnScan');
  if (btnScan) {
    btnScan.addEventListener('click', () => {
      if (!state.activeTab || !state.isValidMapsPage) return;
      updateStatusPill(true, true);
      chrome.tabs.sendMessage(state.activeTab.id, { action: 'SCAN_FEED' }, (response) => {
        updateStatusPill(true, false);
        if (chrome.runtime.lastError) {
          showModal({ title: 'Reconnect Maps Tab', desc: 'Refresh Google Maps tab once to reconnect.', actionText: 'Refresh Tab', callback: () => chrome.tabs.reload(state.activeTab.id) });
          return;
        }
        if (response && response.leads) {
          const prevTotal = state.allLeads.length;
          state.allLeads = mergeAndDeduplicate(state.allLeads, response.leads);
          chrome.storage.local.set({ savedLeads: state.allLeads });
          showToast(`✓ Scanned ${response.leads.length} (${state.allLeads.length - prevTotal > 0 ? `+${state.allLeads.length - prevTotal} new` : 'no new'})`);
          renderUI();
        }
      });
    });
  }
  
  const btnAutoScroll = document.getElementById('btnAutoScroll');
  if (btnAutoScroll) {
    btnAutoScroll.addEventListener('click', () => {
      if (!state.activeTab || !state.isValidMapsPage) return;
      const prevCount = state.allLeads.length;
      updateStatusPill(true, true, 'Auto-Scrolling...');
      btnAutoScroll.disabled = true; btnAutoScroll.textContent = '⏳ Scrolling...';
      if (btnScan) btnScan.disabled = true;
      showToast('⏳ Stepped scroll running...');
      
      chrome.tabs.sendMessage(state.activeTab.id, { action: 'AUTO_SCROLL_AND_SCAN', targetBatch: 30 }, (response) => {
        btnAutoScroll.disabled = false; btnAutoScroll.textContent = 'Auto 30+';
        if (btnScan) btnScan.disabled = false;
        updateStatusPill(true, false);
        if (chrome.runtime.lastError) {
          showModal({ title: 'Reconnect Maps Tab', desc: 'Refresh tab once to reconnect.', actionText: 'Refresh Tab', callback: () => chrome.tabs.reload(state.activeTab.id) });
          return;
        }
        if (response && response.leads) {
          state.allLeads = mergeAndDeduplicate(state.allLeads, response.leads);
          chrome.storage.local.set({ savedLeads: state.allLeads });
          showToast(`✓ Fetched ${response.leads.length} leads (+${state.allLeads.length - prevCount} new)!`);
          renderUI();
        } else { showToast('End of Google Maps results reached.'); }
      });
    });
  }
  
  const btnExport = document.getElementById('btnExport');
  if (btnExport) {
    btnExport.addEventListener('click', () => {
      const displayLeads = getFilteredLeads();
      if (displayLeads.length === 0) return;
      downloadCSV(generateCSV(displayLeads), `mapleads_${Date.now()}.csv`);
      showToast(`✓ Downloaded ${displayLeads.length} leads`);
    });
  }
  
  const btnClosePitch = document.getElementById('btnClosePitch');
  if (btnClosePitch) btnClosePitch.addEventListener('click', () => document.getElementById('pitchModal').classList.add('hidden'));
  
  const btnCopyPitch = document.getElementById('btnCopyPitch');
  if (btnCopyPitch) {
    btnCopyPitch.addEventListener('click', () => {
      const box = document.getElementById('pitchText');
      if (box) { navigator.clipboard.writeText(box.value); showToast('✓ Copied Pitch!'); }
    });
  }
  
  const btnModalAction = document.getElementById('btnModalAction');
  const btnModalDismiss = document.getElementById('btnModalDismiss');
  if (btnModalAction) btnModalAction.addEventListener('click', () => { if (typeof currentModalCallback === 'function') currentModalCallback(); hideModal(); });
  if (btnModalDismiss) btnModalDismiss.addEventListener('click', hideModal);
});